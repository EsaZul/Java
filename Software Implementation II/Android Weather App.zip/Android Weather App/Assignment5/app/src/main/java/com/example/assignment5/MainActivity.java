package com.example.assignment5;

import android.app.Activity;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends Activity {
    private Button button1;

    //public String json = "{\"currently\":{\"time\":1574362467,\"summary\":\"Clear\",\"icon\":\"clear-day\",\"nearestStormDistance\":249,\"nearestStormBearing\":157,\"precipIntensity\":0,\"precipProbability\":0,\"temperature\":59.95,\"apparentTemperature\":59.95,\"dewPoint\":42.73,\"humidity\":0.53,\"pressure\":1011.7,\"windSpeed\":3.35,\"windGust\":6.91,\"windBearing\":202,\"cloudCover\":0.02,\"uvIndex\":2,\"visibility\":10,\"ozone\":309.3}";//,"minutely":{"summary":"Clear for the hour.","icon":"clear-day","data":[{"time":1574362440,"precipIntensity":0,"precipProbability":0},{"time":1574362500,"precipIntensity":0,"precipProbability":0},{"time":1574362560,"precipIntensity":0,"precipProbability":0},{"time":1574362620,"precipIntensity":0,"precipProbability":0},{"time":1574362680,"precipIntensity":0,"precipProbability":0},{"time":1574362740,"precipIntensity":0,"precipProbability":0},{"time":1574362800,"precipIntensity":0,"precipProbability":0},{"time":1574362860,"precipIntensity":0,"precipProbability":0},{"time":1574362920,"precipIntensity":0,"precipProbability":0},{"time":1574362980,"precipIntensity":0,"precipProbability":0},{"time":1574363040,"precipIntensity":0,"precipProbability":0},{"time":1574363100,"precipIntensity":0,"precipProbability":0},{"time":1574363160,"precipIntensity":0,"precipProbability":0},{"time":1574363220,"precipIntensity":0,"precipProbability":0},{"time":1574363280,"precipIntensity":0,"precipProbability":0},{"time":1574363340,"precipIntensity":0,"precipProbability":0},{"time":1574363400,"precipIntensity":0,"precipProbability":0},{"time":1574363460,"precipIntensity":0,"precipProbability":0},{"time":1574363520,"precipIntensity":0,"precipProbability":0},{"time":1574363580,"precipIntensity":0,"precipProbability":0},{"time":1574363640,"precipIntensity":0,"precipProbability":0},{"time":1574363700,"precipIntensity":0,"precipProbability":0},{"time":1574363760,"precipIntensity":0,"precipProbability":0},{"time":1574363820,"precipIntensity":0,"precipProbability":0},{"time":1574363880,"precipIntensity":0,"precipProbability":0},{"time":1574363940,"precipIntensity":0,"precipProbability":0},{"time":1574364000,"precipIntensity":0,"precipProbability":0},{"time":1574364060,"precipIntensity":0,"precipProbability":0},{"time":1574364120,"precipIntensity":0,"precipProbability":0},{"time":1574364180,"precipIntensity":0,"precipProbability":0},{"time":1574364240,"precipIntensity":0,"precipProbability":0},{"time":1574364300,"precipIntensity":0,"precipProbability":0},{"time":1574364360,"precipIntensity":0,"precipProbability":0},{"time":1574364420,"precipIntensity":0,"precipProbability":0},{"time":1574364480,"precipIntensity":0,"precipProbability":0},{"time":1574364540,"precipIntensity":0,"precipProbability":0},{"time":1574364600,"precipIntensity":0,"precipProbability":0},{"time":1574364660,"precipIntensity":0,"precipProbability":0},{"time":1574364720,"precipIntensity":0,"precipProbability":0},{"time":1574364780,"precipIntensity":0,"precipProbability":0},{"time":1574364840,"precipIntensity":0,"precipProbability":0},{"time":1574364900,"precipIntensity":0,"precipProbability":0},{"time":1574364960,"precipIntensity":0,"precipProbability":0},{"time":1574365020,"precipIntensity":0,"precipProbability":0},{"time":1574365080,"precipIntensity":0,"precipProbability":0},{"time":1574365140,"precipIntensity":0,"precipProbability":0},{"time":1574365200,"precipIntensity":0,"precipProbability":0},{"time":1574365260,"precipIntensity":0,"precipProbability":0},{"time":1574365320,"precipIntensity":0,"precipProbability":0},{"time":1574365380,"precipIntensity":0,"precipProbability":0},{"time":1574365440,"precipIntensity":0,"precipProbability":0},{"time":1574365500,"precipIntensity":0,"precipProbability":0},{"time":1574365560,"precipIntensity":0,"precipProbability":0},{"time":1574365620,"precipIntensity":0,"precipProbability":0},{"time":1574365680,"precipIntensity":0,"precipProbability":0},{"time":1574365740,"precipIntensity":0,"precipProbability":0},{"time":1574365800,"precipIntensity":0,"precipProbability":0},{"time":1574365860,"precipIntensity":0,"precipProbability":0},{"time":1574365920,"precipIntensity":0,"precipProbability":0},{"time":1574365980,"precipIntensity":0,"precipProbability":0},{"time":1574366040,"precipIntensity":0,"precipProbability":0}]},"hourly":{"summary":"Clear throughout the day.","icon":"clear-day","data":[{"time":1574359200,"summary":"Clear","icon":"clear-day","precipIntensity":0,"precipProbability":0,"temperature":56.67,"apparentTemperature":56.67,"dewPoint":41.7,"humidity":0.57,"pressure":1011.6,"windSpeed":3.03,"windGust":6.49,"windBearing":196,"cloudCover":0,"uvIndex":2,"visibility":9.924,"ozone":310.6},{"time":1574362800,"summary":"Clear","icon":"clear-day","precipIntensity":0,"precipProbability":0,"temperature":60.25,"apparentTemperature":60.25,"dewPoint":42.86,"humidity":0.53,"pressure":1011.7,"windSpeed":3.4,"windGust":6.97,"windBearing":204,"cloudCover":0.02,"uvIndex":2,"visibility":10,"ozone":309.2},{"time":1574366400,"summary":"Clear","icon":"clear-day","precipIntensity":0.001,"precipProbability":0.02,"precipType":"rain","temperature":63.13,"apparentTemperature":63.13,"dewPoint":44.5,"humidity":0.51,"pressure":1011.7,"windSpeed":4.08,"windGust":7.66,"windBearing":234,"cloudCover":0.05,"uvIndex":3,"visibility":10,"ozone":307.2},{"time":1574370000,"summary":"Clear","icon":"clear-day","precipIntensity":0.0015,"precipProbability":0.02,"precipType":"rain","temperature":64.56,"apparentTemperature":64.56,"dewPoint":47.97,"humidity":0.55,"pressure":1011.7,"windSpeed":4.42,"windGust":7.43,"windBearing":249,"cloudCover":0.1,"uvIndex":2,"visibility":10,"ozone":304.8},{"time":1574373600,"summary":"Clear","icon":"clear-day","precipIntensity":0,"precipProbability":0,"temperature":65.41,"apparentTemperature":65.41,"dewPoint":50.07,"humidity":0.58,"pressure":1011.6,"windSpeed":4.73,"windGust":6.91,"windBearing":222,"cloudCover":0.12,"uvIndex":2,"visibility":10,"ozone":301.6},{"time":1574377200,"summary":"Clear","icon":"clear-day","precipIntensity":0,"precipProbability":0,"temperature":65.19,"apparentTemperature":65.19,"dewPoint":50.05,"humidity":0.58,"pressure":1012.1,"windSpeed":5.19,"windGust":7.96,"windBearing":273,"cloudCover":0.11,"uvIndex":1,"visibility":10,"ozone":297.8},{"time":1574380800,"summary":"Clear","icon":"clear-day","precipIntensity":0.0019,"precipProbability":0.02,"precipType":"rain","temperature":63.77,"apparentTemperature":63.77,"dewPoint":50.27,"humidity":0.61,"pressure":1012.7,"windSpeed":4.84,"windGust":7.59,"windBearing":257,"cloudCover":0.11,"uvIndex":0,"visibility":10,"ozone":294.7},{"time":1574384400,"summary":"Clear","icon":"clear-night","precipIntensity":0.0018,"precipProbability":0.02,"precipType":"rain","temperature":60.7,"apparentTemperature":60.7,"dewPoint":50.69,"humidity":0.7,"pressure":1013.4,"windSpeed":3.93,"windGust":7.09,"windBearing":249,"cloudCover":0.11,"uvIndex":0,"visibility":10,"ozone":292.9},{"time":1574388000,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":57.32,"apparentTemperature":57.32,"dewPoint":50.8,"humidity":0.79,"pressure":1014.2,"windSpeed":3.18,"windGust":6.39,"windBearing":198,"cloudCover":0.1,"uvIndex":0,"visibility":10,"ozone":291.8},{"time":1574391600,"summary":"Clear","icon":"clear-night","precipIntensity":0.0014,"precipProbability":0.03,"precipType":"rain","temperature":54.44,"apparentTemperature":54.44,"dewPoint":50.03,"humidity":0.85,"pressure":1014.9,"windSpeed":2.7,"windGust":5.45,"windBearing":151,"cloudCover":0.1,"uvIndex":0,"visibility":10,"ozone":290.5},{"time":1574395200,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":52.77,"apparentTemperature":52.77,"dewPoint":49.19,"humidity":0.88,"pressure":1015.6,"windSpeed":2.37,"windGust":4.31,"windBearing":146,"cloudCover":0.1,"uvIndex":0,"visibility":10,"ozone":288.8},{"time":1574398800,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":51.56,"apparentTemperature":51.56,"dewPoint":48.56,"humidity":0.89,"pressure":1016.6,"windSpeed":2.44,"windGust":4.2,"windBearing":132,"cloudCover":0.1,"uvIndex":0,"visibility":10,"ozone":287},{"time":1574402400,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":50.49,"apparentTemperature":50.49,"dewPoint":47.86,"humidity":0.91,"pressure":1017.2,"windSpeed":2.55,"windGust":3.85,"windBearing":138,"cloudCover":0.11,"uvIndex":0,"visibility":10,"ozone":285.5},{"time":1574406000,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":49.08,"apparentTemperature":49.08,"dewPoint":46.91,"humidity":0.92,"pressure":1017.8,"windSpeed":2.28,"windGust":2.9,"windBearing":139,"cloudCover":0.12,"uvIndex":0,"visibility":10,"ozone":284.4},{"time":1574409600,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":47.91,"apparentTemperature":47.91,"dewPoint":45.62,"humidity":0.92,"pressure":1018.1,"windSpeed":2.7,"windGust":3.52,"windBearing":144,"cloudCover":0.22,"uvIndex":0,"visibility":10,"ozone":283.6},{"time":1574413200,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":47.4,"apparentTemperature":47.4,"dewPoint":45.11,"humidity":0.92,"pressure":1018.3,"windSpeed":2.72,"windGust":3.3,"windBearing":142,"cloudCover":0.25,"uvIndex":0,"visibility":10,"ozone":283.3},{"time":1574416800,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":46.86,"apparentTemperature":46.86,"dewPoint":44.78,"humidity":0.92,"pressure":1018.6,"windSpeed":2.63,"windGust":3.12,"windBearing":134,"cloudCover":0.27,"uvIndex":0,"visibility":10,"ozone":284.1},{"time":1574420400,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":46.53,"apparentTemperature":46.53,"dewPoint":44.52,"humidity":0.93,"pressure":1018.9,"windSpeed":2.48,"windGust":2.92,"windBearing":125,"cloudCover":0.29,"uvIndex":0,"visibility":10,"ozone":285.3},{"time":1574424000,"summary":"Clear","icon":"clear-night","precipIntensity":0.0002,"precipProbability":0.02,"precipType":"rain","temperature":46.24,"apparentTemperature":46.24,"dewPoint":44.17,"humidity":0.92,"pressure":1019.3,"windSpeed":2.39,"windGust":2.74,"windBearing":117,"cloudCover":0.31,"uvIndex":0,"visibility":10,"ozone":286.1},{"time":1574427600,"summary":"Partly Cloudy","icon":"partly-cloudy-night","precipIntensity":0,"precipProbability":0,"temperature":45.4,"apparentTemperature":45.4,"dewPoint":43.2,"humidity":0.92,"pressure":1019.7,"windSpeed":2.44,"windGust":2.63,"windBearing":115,"cloudCover":0.33,"uvIndex":0,"visibility":10,"ozone":285.8},{"time":1574431200,"summary":"Partly Cloudy","icon":"partly-cloudy-night","precipIntensity":0,"precipProbability":0,"temperature":44.83,"apparentTemperature":44.83,"dewPoint":42.55,"humidity":0.92,"pressure":1020.2,"windSpeed":2.54,"windGust":2.63,"windBearing":113,"cloudCover":0.34,"uvIndex":0,"visibility":10,"ozone":285},{"time":1574434800,"summary":"Partly Cloudy","icon":"partly-cloudy-day","precipIntensity":0,"precipProbability":0,"temperature":45.38,"apparentTemperature":45.38,"dewPoint":43.33,"humidity":0.93,"pressure":1020.7,"windSpeed":2.54,"windGust":2.58,"windBearing":106,"cloudCover":0.36,"uvIndex":0,"visibility":10,"ozone":284},{"time":1574438400,"summary":"Partly Cloudy","icon":"partly-cloudy-day","precipIntensity":0,"precipProbability":0,"temperature":47.6,"apparentTemperature":47.6,"dewPoint":45.22,"humidity":0.91,"pressure":1021.4,"windSpeed":2.24,"windGust":2.29,"windBearing":88,"cloudCover":0.37,"uvIndex":0,"visibility":10,"ozone":283.1},{"time":1574442000,"summary":"Partly Cloudy","icon":"partly-cloudy-day","precipIntensity":0,"precipProbability":0,"temperature":51.36,"apparentTemperature":51.36,"dewPoint":47.65,"humidity":0.87,"pressure":1022.2,"windSpeed":1.84,"windGust":2.37,"windBearing":45,"cloudCover":0.37,"uvIndex":1,"visibility":10,"ozone":282.1},{"time":1574445600,"summary":"Partly Cloudy","icon":"partly-cloudy-day","precipIntensity":0.0002,"precipProbability":0.02,"precipType":"rain","temperature":55.55,"apparentTemperature":55.55,"dewPoint":49,"humidity":0.79,"pressure":1022.7,"windSpeed":1.68,"windGust":2.5,"windBearing":15,"cloudCover":0.36,"uvIndex":2,"visibility":10,"ozone":281.1},{"time":1574449200,"summary":"Clear","icon":"clear-day","precipIntensity":0,"precipProbability":0,"temperature":59.25,"apparentTemperature":59.25,"dewPoint":49.36,"humidity":0.7,"pressure":1022.6,"windSpeed":1.92,"windGust":2.44,"windBearing":357,"cloudCover":0.28,"uvIndex":3,"visibility":10,"ozone":280.1},{"time":1574452800,"summary":"Clear","icon":"clear-day","precipIntensity":0,"precipProbability":0,"temperature":63.17,"apparentTemperature":63.17,"dewPoint":49.49,"humidity":0.61,"pressure":1021.8,"windSpeed":2.39,"windGust":2.5,"windBearing":332,"cloudCover":0.18,"uvIndex":3,"visibility":10,"ozone":279.1},{"time":1574456400,"summary":"Clear","icon":"clear-day","precipIntensity":0,"precipProbability":0,"temperature":65.75,"apparentTemperature":65.75,"dewPoint":49.39,"humidity":0.56,"pressure":1021.3,"windSpeed":2.93,"windGust":3.1,"windBearing":313,"cloudCover":0.1,"uvIndex":3,"visibility":10,"ozone":278.5},{"time":1574460000,"summary":"Clear","icon":"clear-day","precipIntensity":0.0004,"precipProbability":0.01,"precipType":"rain","temperature":67,"apparentTemperature":67,"dewPoint":49.14,"humidity":0.53,"pressure":1021.1,"windSpeed":3.73,"windGust":4.03,"windBearing":308,"cloudCover":0.06,"uvIndex":2,"visibility":10,"ozone":277.9},{"time":1574463600,"summary":"Clear","icon":"clear-day","precipIntensity":0.0003,"precipProbability":0.01,"precipType":"rain","temperature":66.88,"apparentTemperature":66.88,"dewPoint":48.79,"humidity":0.52,"pressure":1021.1,"windSpeed":4.65,"windGust":5.77,"windBearing":319,"cloudCover":0.06,"uvIndex":1,"visibility":10,"ozone":277.4},{"time":1574467200,"summary":"Clear","icon":"clear-day","precipIntensity":0,"precipProbability":0,"temperature":65.54,"apparentTemperature":65.54,"dewPoint":48.42,"humidity":0.54,"pressure":1021.3,"windSpeed":5.14,"windGust":7.15,"windBearing":316,"cloudCover":0.05,"uvIndex":0,"visibility":10,"ozone":277.9},{"time":1574470800,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":62.58,"apparentTemperature":62.58,"dewPoint":48.59,"humidity":0.6,"pressure":1021.7,"windSpeed":4.93,"windGust":7.89,"windBearing":316,"cloudCover":0.03,"uvIndex":0,"visibility":10,"ozone":280},{"time":1574474400,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":58.73,"apparentTemperature":58.73,"dewPoint":48.85,"humidity":0.7,"pressure":1022.2,"windSpeed":4.32,"windGust":8.24,"windBearing":320,"cloudCover":0.02,"uvIndex":0,"visibility":10,"ozone":282.9},{"time":1574478000,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":55.07,"apparentTemperature":55.07,"dewPoint":48.47,"humidity":0.78,"pressure":1022.7,"windSpeed":3.74,"windGust":7.93,"windBearing":334,"cloudCover":0.02,"uvIndex":0,"visibility":10,"ozone":285.3},{"time":1574481600,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":53.21,"apparentTemperature":53.21,"dewPoint":48.01,"humidity":0.82,"pressure":1023.4,"windSpeed":3.26,"windGust":6.5,"windBearing":13,"cloudCover":0.03,"uvIndex":0,"visibility":10,"ozone":286.8},{"time":1574485200,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":51.88,"apparentTemperature":51.88,"dewPoint":47.68,"humidity":0.86,"pressure":1023.6,"windSpeed":2.8,"windGust":4.42,"windBearing":69,"cloudCover":0.06,"uvIndex":0,"visibility":10,"ozone":288},{"time":1574488800,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":50.67,"apparentTemperature":50.67,"dewPoint":47.04,"humidity":0.87,"pressure":1023.9,"windSpeed":2.44,"windGust":3.18,"windBearing":93,"cloudCover":0.09,"uvIndex":0,"visibility":10,"ozone":288.1},{"time":1574492400,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":49.47,"apparentTemperature":49.47,"dewPoint":46,"humidity":0.88,"pressure":1023.9,"windSpeed":2.16,"windGust":2.61,"windBearing":86,"cloudCover":0.13,"uvIndex":0,"visibility":10,"ozone":286.9},{"time":1574496000,"summary":"Clear","icon":"clear-night","precipIntensity":0.0003,"precipProbability":0.01,"precipType":"rain","temperature":48.58,"apparentTemperature":48.58,"dewPoint":45.14,"humidity":0.88,"pressure":1023.7,"windSpeed":1.95,"windGust":2.25,"windBearing":92,"cloudCover":0.18,"uvIndex":0,"visibility":10,"ozone":284.7},{"time":1574499600,"summary":"Clear","icon":"clear-night","precipIntensity":0.0002,"precipProbability":0.01,"precipType":"rain","temperature":47.93,"apparentTemperature":47.93,"dewPoint":44.86,"humidity":0.89,"pressure":1023.7,"windSpeed":1.87,"windGust":2.11,"windBearing":96,"cloudCover":0.21,"uvIndex":0,"visibility":10,"ozone":282.8},{"time":1574503200,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":47.37,"apparentTemperature":47.37,"dewPoint":44.62,"humidity":0.9,"pressure":1023.7,"windSpeed":1.99,"windGust":2.22,"windBearing":99,"cloudCover":0.22,"uvIndex":0,"visibility":10,"ozone":281.5},{"time":1574506800,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":46.86,"apparentTemperature":46.86,"dewPoint":44.22,"humidity":0.9,"pressure":1023.6,"windSpeed":2.23,"windGust":2.52,"windBearing":101,"cloudCover":0.22,"uvIndex":0,"visibility":10,"ozone":280.3},{"time":1574510400,"summary":"Clear","icon":"clear-night","precipIntensity":0.0003,"precipProbability":0.01,"precipType":"rain","temperature":46.28,"apparentTemperature":46.28,"dewPoint":43.71,"humidity":0.91,"pressure":1023.7,"windSpeed":2.44,"windGust":2.81,"windBearing":100,"cloudCover":0.21,"uvIndex":0,"visibility":10,"ozone":279.4},{"time":1574514000,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":45.31,"apparentTemperature":45.31,"dewPoint":42.75,"humidity":0.91,"pressure":1023.8,"windSpeed":2.57,"windGust":2.94,"windBearing":100,"cloudCover":0.2,"uvIndex":0,"visibility":10,"ozone":279},{"time":1574517600,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":44.47,"apparentTemperature":44.47,"dewPoint":42.12,"humidity":0.91,"pressure":1024.1,"windSpeed":2.67,"windGust":3,"windBearing":100,"cloudCover":0.19,"uvIndex":0,"visibility":10,"ozone":278.7},{"time":1574521200,"summary":"Clear","icon":"clear-night","precipIntensity":0,"precipProbability":0,"temperature":45.13,"apparentTemperature":45.13,"dewPoint":42.78,"humidity":0.91,"pressure":1024.4,"windSpeed":2.69,"windGust":2.98,"windBearing":92,"cloudCover":0.17,"uvIndex":0,"visibility":10,"ozone":278.3},{"time":1574524800,"summary":"Clear","icon":"clear-day","precipIntensity":0,"precipProbability":0,"temperature":48.17,"apparentTemperature":48.17,"dewPoint":44.42,"humidity":0.87,"pressure":1024.9,"windSpeed":2.5,"windGust":2.7,"windBearing":75,"cloudCover":0.15,"uvIndex":0,"visibility":10,"ozone":277.2},{"time":1574528400,"summary":"Clear","icon":"clear-day","precipIntensity":0,"precipProbability":0,"temperature":53.24,"apparentTemperature":53.24,"dewPoint":45.97,"humidity":0.76,"pressure":1025.4,"windSpeed":2.24,"windGust":2.57,"windBearing":47,"cloudCover":0.12,"uvIndex":1,"visibility":10,"ozone":276.1},{"time":1574532000,"summary":"Clear","icon":"clear-day","precipIntensity":0,"precipProbability":0,"temperature":58.39,"apparentTemperature":58.39,"dewPoint":46.91,"humidity":0.66,"pressure":1025.6,"windSpeed":2.27,"windGust":2.81,"windBearing":21,"cloudCover":0.09,"uvIndex":2,"visibility":10,"ozone":275}]},"daily":{"summary":"Light rain on Tuesday through next Thursday.","icon":"rain","data":[{"time":1574323200,"summary":"Clear throughout the day.","icon":"clear-day","sunriseTime":1574348160,"sunsetTime":1574384160,"moonPhase":0.84,"precipIntensity":0.0004,"precipIntensityMax":0.0021,"precipIntensityMaxTime":1574382420,"precipProbability":0.06,"precipType":"rain","temperatureHigh":65.96,"temperatureHighTime":1574374740,"temperatureLow":44.34,"temperatureLowTime":1574431260,"apparentTemperatureHigh":65.46,"apparentTemperatureHighTime":1574374740,"apparentTemperatureLow":44.83,"apparentTemperatureLowTime":1574431260,"dewPoint":43.69,"humidity":0.68,"pressure":1011.7,"windSpeed":3.35,"windGust":7.98,"windGustTime":1574377680,"windBearing":210,"cloudCover":0.06,"uvIndex":3,"uvIndexTime":1574366100,"visibility":9.996,"ozone":301.9,"temperatureMin":45.77,"temperatureMinTime":1574347800,"temperatureMax":65.96,"temperatureMaxTime":1574374740,"apparentTemperatureMin":45.29,"apparentTemperatureMinTime":1574347440,"apparentTemperatureMax":65.46,"apparentTemperatureMaxTime":1574374740},{"time":1574409600,"summary":"Clear throughout the day.","icon":"clear-day","sunriseTime":1574434620,"sunsetTime":1574470500,"moonPhase":0.87,"precipIntensity":0.0002,"precipIntensityMax":0.0004,"precipIntensityMaxTime":1574460540,"precipProbability":0.07,"precipType":"rain","temperatureHigh":67.61,"temperatureHighTime":1574461440,"temperatureLow":43.98,"temperatureLowTime":1574518020,"apparentTemperatureHigh":67.11,"apparentTemperatureHighTime":1574461440,"apparentTemperatureLow":44.47,"apparentTemperatureLowTime":1574518020,"dewPoint":46.84,"humidity":0.79,"pressure":1021.4,"windSpeed":2.93,"windGust":8.24,"windGustTime":1574474760,"windBearing":18,"cloudCover":0.19,"uvIndex":3,"uvIndexTime":1574452860,"visibility":10,"ozone":283,"temperatureMin":44.34,"temperatureMinTime":1574431260,"temperatureMax":67.61,"temperatureMaxTime":1574461440,"apparentTemperatureMin":44.83,"apparentTemperatureMinTime":1574431260,"apparentTemperatureMax":67.11,"apparentTemperatureMaxTime":1574461440},{"time":1574496000,"summary":"Clear throughout the day.","icon":"clear-day","sunriseTime":1574521080,"sunsetTime":1574556900,"moonPhase":0.91,"precipIntensity":0.0001,"precipIntensityMax":0.0003,"precipIntensityMaxTime":1574544000,"precipProbability":0.04,"precipType":"rain","temperatureHigh":69.77,"temperatureHighTime":1574547300,"temperatureLow":43.66,"temperatureLowTime":1574603940,"apparentTemperatureHigh":69.27,"apparentTemperatureHighTime":1574547300,"apparentTemperatureLow":44.15,"apparentTemperatureLowTime":1574603940,"dewPoint":45.01,"humidity":0.72,"pressure":1023.7,"windSpeed":2.93,"windGust":7.27,"windGustTime":1574552760,"windBearing":14,"cloudCover":0.08,"uvIndex":3,"uvIndexTime":1574539080,"visibility":10,"ozone":274.4,"temperatureMin":43.98,"temperatureMinTime":1574518020,"temperatureMax":69.77,"temperatureMaxTime":1574547300,"apparentTemperatureMin":44.47,"apparentTemperatureMinTime":1574518020,"apparentTemperatureMax":69.27,"apparentTemperatureMaxTime":1574547300},{"time":1574582400,"summary":"Clear throughout the day.","icon":"clear-day","sunriseTime":1574607540,"sunsetTime":1574643240,"moonPhase":0.95,"precipIntensity":0.0001,"precipIntensityMax":0.0002,"precipIntensityMaxTime":1574660940,"precipProbability":0.04,"precipType":"rain","temperatureHigh":68.14,"temperatureHighTime":1574630040,"temperatureLow":42.84,"temperatureLowTime":1574691600,"apparentTemperatureHigh":67.64,"apparentTemperatureHighTime":1574630040,"apparentTemperatureLow":43.33,"apparentTemperatureLowTime":1574691600,"dewPoint":42.34,"humidity":0.67,"pressure":1021.8,"windSpeed":2.42,"windGust":7.41,"windGustTime":1574639220,"windBearing":342,"cloudCover":0.03,"uvIndex":3,"uvIndexTime":1574625360,"visibility":10,"ozone":272.5,"temperatureMin":43.66,"temperatureMinTime":1574603940,"temperatureMax":68.14,"temperatureMaxTime":1574630040,"apparentTemperatureMin":44.15,"apparentTemperatureMinTime":1574603940,"apparentTemperatureMax":67.64,"apparentTemperatureMaxTime":1574630040},{"time":1574668800,"summary":"Partly cloudy throughout the day.","icon":"partly-cloudy-day","sunriseTime":1574694000,"sunsetTime":1574729640,"moonPhase":0.98,"precipIntensity":0.0007,"precipIntensityMax":0.0039,"precipIntensityMaxTime":1574737560,"precipProbability":0.05,"precipType":"rain","temperatureHigh":65.79,"temperatureHighTime":1574716680,"temperatureLow":46.1,"temperatureLowTime":1574778780,"apparentTemperatureHigh":65.29,"apparentTemperatureHighTime":1574716680,"apparentTemperatureLow":44.39,"apparentTemperatureLowTime":1574776380,"dewPoint":43.14,"humidity":0.69,"pressure":1016.7,"windSpeed":4.41,"windGust":14.68,"windGustTime":1574723160,"windBearing":295,"cloudCover":0.52,"uvIndex":3,"uvIndexTime":1574712660,"visibility":10,"ozone":280.4,"temperatureMin":42.84,"temperatureMinTime":1574691600,"temperatureMax":65.79,"temperatureMaxTime":1574716680,"apparentTemperatureMin":43.33,"apparentTemperatureMinTime":1574691600,"apparentTemperatureMax":65.29,"apparentTemperatureMaxTime":1574716680},{"time":1574755200,"summary":"Light rain in the evening and overnight.","icon":"rain","sunriseTime":1574780460,"sunsetTime":1574816040,"moonPhase":0.02,"precipIntensity":0.008,"precipIntensityMax":0.0432,"precipIntensityMaxTime":1574836200,"precipProbability":0.77,"precipType":"rain","temperatureHigh":56.19,"temperatureHighTime":1574799720,"temperatureLow":39.51,"temperatureLowTime":1574844780,"apparentTemperatureHigh":55.69,"apparentTemperatureHighTime":1574799720,"apparentTemperatureLow":33.92,"apparentTemperatureLowTime":1574844840,"dewPoint":40.55,"humidity":0.74,"pressure":1006.5,"windSpeed":6.34,"windGust":23.98,"windGustTime":1574841600,"windBearing":287,"cloudCover":0.92,"uvIndex":2,"uvIndexTime":1574797500,"visibility":8.908,"ozone":323.5,"temperatureMin":39.74,"temperatureMinTime":1574841600,"temperatureMax":56.19,"temperatureMaxTime":1574799720,"apparentTemperatureMin":34.44,"apparentTemperatureMinTime":1574841600,"apparentTemperatureMax":55.69,"apparentTemperatureMaxTime":1574799720},{"time":1574841600,"summary":"Mostly cloudy throughout the day.","icon":"rain","sunriseTime":1574866920,"sunsetTime":1574902380,"moonPhase":0.06,"precipIntensity":0.0123,"precipIntensityMax":0.0379,"precipIntensityMaxTime":1574841600,"precipProbability":0.84,"precipType":"rain","temperatureHigh":54.07,"temperatureHighTime":1574888820,"temperatureLow":43,"temperatureLowTime":1574949420,"apparentTemperatureHigh":53.57,"apparentTemperatureHighTime":1574888820,"apparentTemperatureLow":39.46,"apparentTemperatureLowTime":1574950260,"dewPoint":39.3,"humidity":0.78,"pressure":1002,"windSpeed":8.2,"windGust":25.69,"windGustTime":1574845020,"windBearing":157,"cloudCover":0.68,"uvIndex":2,"uvIndexTime":1574884260,"visibility":8.828,"ozone":399.4,"temperatureMin":39.51,"temperatureMinTime":1574844780,"temperatureMax":54.07,"temperatureMaxTime":1574888820,"apparentTemperatureMin":33.92,"apparentTemperatureMinTime":1574844840,"apparentTemperatureMax":53.57,"apparentTemperatureMaxTime":1574888820},{"time":1574928000,"summary":"Clear throughout the day.","icon":"rain","sunriseTime":1574953380,"sunsetTime":1574988780,"moonPhase":0.09,"precipIntensity":0.0077,"precipIntensityMax":0.0152,"precipIntensityMaxTime":1574960280,"precipProbability":0.5,"precipType":"rain","temperatureHigh":53.52,"temperatureHighTime":1574974980,"temperatureLow":40.58,"temperatureLowTime":1575037440,"apparentTemperatureHigh":53.02,"apparentTemperatureHighTime":1574974980,"apparentTemperatureLow":38.33,"apparentTemperatureLowTime":1575037680,"dewPoint":40.49,"humidity":0.79,"pressure":1007.5,"windSpeed":6.94,"windGust":9.07,"windGustTime":1574974860,"windBearing":101,"cloudCover":0.02,"uvIndex":2,"uvIndexTime":1574971020,"visibility":10,"ozone":379.2,"temperatureMin":42.84,"temperatureMinTime":1575014400,"temperatureMax":53.52,"temperatureMaxTime":1574974980,"apparentTemperatureMin":39.46,"apparentTemperatureMinTime":1574950260,"apparentTemperatureMax":53.02,"apparentTemperatureMaxTime":1574974980}]},"flags":{"sources":["nwspa","cmc","gfs","hrrr","icon","isd","madis","nam","sref","darksky","nearest-precip"],"nearest-station":1.311,"units":"us"},"offset":-8}

    private String data = null;
    // Holds an instance of the GPSTracker class
    GPSTracker gps;

    // Holds an instance of the Darksky API
    Darksky darksky;

    String url;

    // Holds weather data for the next 7 days
    final String[] currentTime = new String[5];

    final int pastHour = 3600;
    final int pastDay = 86400;
    final int pastMonth = 2592000;
    final int pastYear = 31536000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Instantiate GPS object
        gps = new GPSTracker(MainActivity.this);

        // Check if GPS is enabled
        if (gps.canGetLocation()) {
            Toast.makeText(getApplicationContext(), "Latitude: " + gps.getLatitude() + " // Longitude: " + gps.getLongitude(), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(getApplicationContext(), "Unable to get location. :(", Toast.LENGTH_LONG).show();
        }

        // Set up API requester with location data
        darksky = new Darksky(gps.getLatitude(), gps.getLongitude());

        url = darksky.getUrl(url);

        getWeatherConditions(url);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);

        return true;
    }

    public void button1Pressed(View view) {

        Log.i("event", "Button 1 Pressed");
        getWeatherConditions(url);

    }


    void getWeatherConditions(String url) {

        final TextView Temperature = (TextView) this.findViewById(R.id.Text1);
        final TextView Humidity = (TextView) this.findViewById(R.id.Text2);
        final TextView Wind_Speed = (TextView) this.findViewById(R.id.Text3);
        final TextView Precipitation = (TextView) this.findViewById(R.id.Text4);
        final TextView Empty = (TextView) this.findViewById(R.id.Text5);

        Request request = new Request.Builder()
                .url(url)
                .build();

        OkHttpClient client = new OkHttpClient();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        data = response.body().string();
                        JSONObject jsonObj = new JSONObject(data);
                        JSONObject currentWeather = jsonObj.getJSONObject("currently");

                        final String currentTemp = currentWeather.getString("temperature");
                        final String currentPrecipitation = currentWeather.getString("precipIntensity");
                        final String currentWindSpeed = currentWeather.getString("windSpeed");
                        final String currentHumidity = currentWeather.getString("humidity");
                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                Temperature.setText(currentTemp + " °F");
                                Precipitation.setText("Precipitation: " + (Double.valueOf(currentPrecipitation) * 100) + "%");
                                Wind_Speed.setText("Wind Speed: " + currentWindSpeed + " mph");
                                Humidity.setText("Humidity: " + (Double.valueOf(currentHumidity) * 100) + "%");
                                Empty.setText(" ");
                            }
                        });

                    } catch (JSONException e) {
                        System.out.println("Error");
                    }

                }
            }
        });
    }


    public void button2Pressed(View view) {

        Log.i("event", "Button 2 Pressed");
        getHrbyHrTemp(url);
    }



    void getHrbyHrTemp(String url) {

        final TextView firstHour = (TextView) this.findViewById(R.id.Text1);
        final TextView secondHour = (TextView) this.findViewById(R.id.Text2);
        final TextView thirdHour = (TextView) this.findViewById(R.id.Text3);
        final TextView fourthHour = (TextView) this.findViewById(R.id.Text4);
        final TextView fifthHour = (TextView) this.findViewById(R.id.Text5);


        Request request = new Request.Builder()
                .url(url)
                .build();

        OkHttpClient client = new OkHttpClient();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        data = response.body().string();
                        JSONObject jsonObj = new JSONObject(data);
                        JSONObject currentWeather = jsonObj.getJSONObject("hourly");
                        JSONArray HourlyTime = currentWeather.getJSONArray("data");

                        JSONObject Hour1JSON= new JSONObject(HourlyTime.get(0).toString());
                        JSONObject Hour2JSON= new JSONObject(HourlyTime.get(1).toString());
                        JSONObject Hour3JSON= new JSONObject(HourlyTime.get(2).toString());
                        JSONObject Hour4JSON= new JSONObject(HourlyTime.get(3).toString());
                        JSONObject Hour5JSON= new JSONObject(HourlyTime.get(4).toString());


                        final String first_Hour = Hour1JSON.getString("temperature");
                        final String second_Hour = Hour2JSON.getString("temperature");
                        final String third_Hour = Hour3JSON.getString("temperature");
                        final String fourth_Hour = Hour4JSON.getString("temperature");
                        final String fifth_Hour = Hour5JSON.getString("temperature");

                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                firstHour.setText("1st Hour " + first_Hour + " °F");
                                secondHour.setText("2nd Hour: " + second_Hour + " °F");
                                thirdHour.setText("3rd Hour: " + third_Hour + " °F");
                                fourthHour.setText("4th Hour: " + fourth_Hour + " °F");
                                fifthHour.setText("5th Hour: " + fifth_Hour + " °F");
                            }
                        });

                    } catch (JSONException e) {
                        System.out.println("Error");
                    }

                }
            }
        });
    }




    public void button3Pressed(View view) {

        Log.i("event", "Button 3 Pressed");
        getAverageTemp48hrs(url);
    }

    void getAverageTemp48hrs(String url) {

        final TextView averageTemp = (TextView) this.findViewById(R.id.Text1);
        final TextView space1 = (TextView) this.findViewById(R.id.Text2);
        final TextView space2 = (TextView) this.findViewById(R.id.Text3);
        final TextView space3 = (TextView) this.findViewById(R.id.Text4);
        final TextView space4 = (TextView) this.findViewById(R.id.Text5);


        Request request = new Request.Builder()
                .url(url)
                .build();

        OkHttpClient client = new OkHttpClient();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        data = response.body().string();
                        JSONObject jsonObj = new JSONObject(data);
                        JSONObject currentWeather = jsonObj.getJSONObject("hourly");
                        JSONArray HourlyTime = currentWeather.getJSONArray("data");

                        double sum = 0;
                        for(int i = 0; i < 48; i++) {
                            JSONObject HourJSON = new JSONObject(HourlyTime.get(i).toString());
                            sum += HourJSON.getInt("temperature");
                        }
                        sum /= 48;
                        final double finalAverage = sum;

                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                averageTemp.setText("Average temperature in the next 48hrs:");
                                space1.setText(Double.toString(finalAverage)+ " °F");
                                space2.setText("                        ");
                                space3.setText("                        ");
                                space4.setText("                        ");
                            }
                        });

                    } catch (JSONException e) {
                        System.out.println("Error");
                    }

                }
            }
        });
    }






    public void button4Pressed(View view) {

        Log.i("event", "Button 4 Pressed");
        getPredictedTemp(url);
    }

    void getPredictedTemp(String url) {

        final TextView predictedTemp1 = (TextView) this.findViewById(R.id.Text1);
        final TextView predictedTemp2 = (TextView) this.findViewById(R.id.Text2);
        final TextView predictedTemp3 = (TextView) this.findViewById(R.id.Text3);
        final TextView predictedTemp4 = (TextView) this.findViewById(R.id.Text4);
        final TextView predictedTemp5 = (TextView) this.findViewById(R.id.Text5);


        Request request = new Request.Builder()
                .url(url)
                .build();

        OkHttpClient client = new OkHttpClient();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        data = response.body().string();
                        JSONObject jsonObj = new JSONObject(data);
                        JSONObject currentWeather = jsonObj.getJSONObject("daily");
                        JSONArray DailyTime = currentWeather.getJSONArray("data");

                        double day1 = 0;
                        double day2 = 0;
                        double day3 = 0;
                        double day4 = 0;
                        double day5 = 0;
                        double day6 = 0;
                        double day7 = 0;

                        for(int i = 0; i < 7; i++) {
                            JSONObject HourJSON = new JSONObject(DailyTime.get(i).toString());
                            if(i == 0) day1 = (HourJSON.getInt("temperatureHigh") + HourJSON.getInt("temperatureMin"))/2;
                            if(i == 1) day2 = (HourJSON.getInt("temperatureHigh") + HourJSON.getInt("temperatureMin"))/2;
                            if(i == 2) day3 = (HourJSON.getInt("temperatureHigh") + HourJSON.getInt("temperatureMin"))/2;
                            if(i == 3) day4 = (HourJSON.getInt("temperatureHigh") + HourJSON.getInt("temperatureMin"))/2;
                            if(i == 4) day5 = (HourJSON.getInt("temperatureHigh") + HourJSON.getInt("temperatureMin"))/2;
                            if(i == 5) day6 = (HourJSON.getInt("temperatureHigh") + HourJSON.getInt("temperatureMin"))/2;
                            if(i == 6) day7 = (HourJSON.getInt("temperatureHigh") + HourJSON.getInt("temperatureMin"))/2;

                        }

                        final double tempDay1 = day1;
                        final double tempDay2 = day2;
                        final double tempDay3 = day3;
                        final double tempDay4 = day4;
                        final double tempDay5 = day5;
                        final double tempDay6 = day6;
                        final double tempDay7 = day7;


                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                predictedTemp1.setText("Day 1: " + Double.toString(tempDay1)+ " °F" + "    Day 6: " +Double.toString(tempDay6) + " °F");
                                predictedTemp2.setText("Day 2: " + Double.toString(tempDay2)+ " °F" + "    Day 7: " +Double.toString(tempDay7) + " °F");
                                predictedTemp3.setText("Day 3: " + Double.toString(tempDay3)+ " °F");
                                predictedTemp4.setText("Day 4: " + Double.toString(tempDay4)+ " °F");
                                predictedTemp5.setText("Day 5: " + Double.toString(tempDay5)+ " °F");
                            }
                        });

                    } catch (JSONException e) {
                        System.out.println("Error");
                    }

                }
            }
        });
    }





    public void button5Pressed(View view) {

        Log.i("event", "Button 5 Pressed");

        getPastTemp(url);
        getPastHour(url);
        getPastDay(url);
        getPastMonth(url);
        getPastYear(url);

    }
    void getPastTemp(String url) {

        final TextView Hour = (TextView) this.findViewById(R.id.Text1);
        final TextView Day = (TextView) this.findViewById(R.id.Text2);
        final TextView Month = (TextView) this.findViewById(R.id.Text3);
        final TextView Year = (TextView) this.findViewById(R.id.Text4);
        final TextView space4 = (TextView) this.findViewById(R.id.Text5);

        Request request = new Request.Builder()
                .url(url)
                .build();

        OkHttpClient client = new OkHttpClient();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        data = response.body().string();
                        JSONObject jsonObj = new JSONObject(data);
                        JSONObject currentWeather = jsonObj.getJSONObject("currently");

                        currentTime[0] = currentWeather.getString("time");
                        currentTime[1] = Integer.toString(Integer.parseInt(currentTime[0]) - pastHour);
                        currentTime[2] = Integer.toString(Integer.parseInt(currentTime[0]) - pastDay);
                        currentTime[3] = Integer.toString(Integer.parseInt(currentTime[0]) - pastMonth);
                        currentTime[4] = Integer.toString(Integer.parseInt(currentTime[0]) - pastYear);


                    } catch (JSONException e) {
                        System.out.println("Error");
                    }

                }
            }
        });
    }

    void getPastHour(String url) {
        final TextView Hour = (TextView) this.findViewById(R.id.Text1);

        Request request1 = new Request.Builder()
                .url(url + "," + currentTime[1])
                .build();

        OkHttpClient client = new OkHttpClient();

        client.newCall(request1).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        data = response.body().string();
                        JSONObject jsonObj = new JSONObject(data);
                        JSONObject currentWeather = jsonObj.getJSONObject("currently");

                        final String currentTemp = currentWeather.getString("temperature");
                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                Hour.setText("Past Hour: " + currentTemp + " °F");
                            }
                        });

                    } catch (JSONException e) {
                        System.out.println("Error");
                    }

                }
            }
        });
    }

    void getPastDay(String url) {
        final TextView Day = (TextView) this.findViewById(R.id.Text2);

        Request request2 = new Request.Builder()
                .url(url + "," + currentTime[2])
                .build();

        OkHttpClient client = new OkHttpClient();

        client.newCall(request2).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        data = response.body().string();
                        JSONObject jsonObj = new JSONObject(data);
                        JSONObject currentWeather = jsonObj.getJSONObject("currently");

                        final String currentTemp = currentWeather.getString("temperature");
                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                Day.setText("Past Day: " + currentTemp + " °F");
                            }
                        });

                    } catch (JSONException e) {
                        System.out.println("Error");
                    }

                }
            }
        });
    }

    void getPastMonth(String url) {

        final TextView Month = (TextView) this.findViewById(R.id.Text3);

        Request request = new Request.Builder()
                .url(url + "," + currentTime[3])
                .build();

        OkHttpClient client = new OkHttpClient();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        data = response.body().string();
                        JSONObject jsonObj = new JSONObject(data);
                        JSONObject currentWeather = jsonObj.getJSONObject("currently");

                        final String currentTemp = currentWeather.getString("temperature");
                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                Month.setText("Past Month: " + currentTemp + " °F");
                            }
                        });

                    } catch (JSONException e) {
                        System.out.println("Error");
                    }

                }
            }
        });
    }

    void getPastYear(String url){

        final TextView Year = (TextView) this.findViewById(R.id.Text4);
        final TextView space4 = (TextView) this.findViewById(R.id.Text5);


        Request request = new Request.Builder()
                .url(url + "," + currentTime[4])
                .build();

        OkHttpClient client4 = new OkHttpClient();

        client4.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        data = response.body().string();
                        JSONObject jsonObj = new JSONObject(data);
                        JSONObject currentWeather = jsonObj.getJSONObject("currently");

                        final String currentTemp = currentWeather.getString("temperature");
                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                Year.setText("Past Year: " + currentTemp + " °F");
                                space4.setText("Past Temperatures from current time");
                            }
                        });

                    } catch (JSONException e) {
                        System.out.println("Error");
                    }

                }
            }
        });

    }

}
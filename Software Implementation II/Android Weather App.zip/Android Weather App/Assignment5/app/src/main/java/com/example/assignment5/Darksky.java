package com.example.assignment5;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;
import com.loopj.android.http.*;


import android.util.Log;

import cz.msebera.android.httpclient.Header;


public class Darksky {

    // https://api.forecast.io/forecast/c009c5573e8ced3863c90a4113d03288/28.854167,128.041667?units=uk&exclude=hourly%2Calerts%2Cflags

    public static final String BASE_URL = "https://api.forecast.io/forecast/";
    public static final String API_KEY = "00398d18c304ef9945e2d8f5ae2e9b2e";

    // Location data
    protected double latitude;
    protected double longitude;

    // Holds weather information for the entire week


    ArrayList<weeklyForecast> weeklyForecast = new ArrayList<weeklyForecast>();


    private AsyncHttpClient client = new AsyncHttpClient();

    public Darksky(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
        client = new AsyncHttpClient();
    }

    public String getUrl(String url) {
        url = BASE_URL + API_KEY + "/" + latitude + "," + longitude;
        return url;
    }

}
